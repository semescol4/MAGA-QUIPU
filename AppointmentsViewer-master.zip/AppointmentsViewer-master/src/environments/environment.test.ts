export const environment = {
  production: true,
  APIEndpoint: 'https://horarios.checkpoint.test.telefe.com.ar/api'
};
