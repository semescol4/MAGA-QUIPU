export const environment = {
    production: false,
    APIEndpoint: 'https://167.114.50.77:7380/api'
};
