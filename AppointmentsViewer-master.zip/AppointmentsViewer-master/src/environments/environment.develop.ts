export const environment = {
  production: false,
  APIEndpoint: 'https://horarios.checkpoint.desa.telefe.com.ar/api'
};
