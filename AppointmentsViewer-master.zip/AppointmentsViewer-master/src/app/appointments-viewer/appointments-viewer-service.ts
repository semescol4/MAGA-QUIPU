import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import * as Moment from 'moment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CitacionResponse } from '../models/citacion/citacion-response';
import { Empleado } from '../models/empleado/empleado';
import { environment } from '../../environments/environment';
import { CitacionSearch } from '../models/citacion/citacion.search';
import { EmpleadoSearch } from '../models/empleado/empleado.search';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})

export class AppointmentsViewerService implements OnInit {
  ngOnInit(): void {
  }

  constructor(private http: HttpClient) {
  }


  public getCitacionResult(searchFilter: CitacionSearch): Observable<CitacionResponse> {
    const parameters = 'searchFilter.legajo=' + searchFilter.Legajo
      + '&searchFilter.tipodocumento=' + searchFilter.TipoDocumento
      + '&searchFilter.documento=' + searchFilter.Documento
      + '&searchFilter.fechaDesde=' + Moment(searchFilter.FechaDesde).utc().format()
      + '&searchFilter.fechaHasta=' + Moment(searchFilter.FechaHasta).utc().format();

    const apiUrl = environment.APIEndpoint + '/appointmentviewer?' + parameters;

    return this.http.get<CitacionResponse>(apiUrl);
  }

  public getEmpleadoByPersonalData(empleadoSearch: EmpleadoSearch): Observable<Empleado> {
    const params = 'searchFilter.legajo=' + empleadoSearch.Legajo
      + '&searchFilter.tipoDocumento=' + empleadoSearch.TipoDocumento
      + '&searchFilter.documento=' + empleadoSearch.Documento;

    const apiUrl = environment.APIEndpoint + '/employee?' + params;

    return this.http.get<Empleado>(apiUrl);
  }

  public onError(err: any): void {
    console.error(err);
  }

  public onSuccess(result: Empleado, exists: boolean): void {
    if (result.Legajo > 0) {
      exists = true;
    }
  }

  private extractData(response: Response) {
    if (response.status < 200 || response.status >= 300) {
      throw new Error('Bad response status: ' + response.status);
    }
    const body = response.json();
    return body || {};
  }

  private handleError(error: any) {
    const errorMsg = error.message || 'Server error';
    console.error(errorMsg); // log to console instead
    return Observable.throw(errorMsg);
  }
}

