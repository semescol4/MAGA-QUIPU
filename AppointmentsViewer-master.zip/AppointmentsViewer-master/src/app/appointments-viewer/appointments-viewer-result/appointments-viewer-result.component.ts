import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Router } from '@angular/router';
import * as Moment from 'moment';
import { AppointmentsViewerService } from '../appointments-viewer-service';
import { CitacionViewModel } from 'src/app/models/citacion/citacion-view.model';
import { CitacionResponse } from 'src/app/models/citacion/citacion-response';
import { timer } from 'rxjs';
import { CitacionSearch } from 'src/app/models/citacion/citacion.search';

@Component({
  selector: 'app-appointments-viewer-result',
  templateUrl: './appointments-viewer-result.component.html',
  styleUrls: ['./appointments-viewer-result.component.scss']
})

export class AppointmentsViewerResultComponent implements OnInit {
  public viewModel: CitacionViewModel[] = [];
  public currentDate: Date;
  public startOfWeekStr: string;
  public endOfWeekStr: string;
  public empleado: string;
  public legajo: string;
  public tipodocumento: string;
  public documento: string;
  private searchDateFrom: Date;
  private searchDateTo: Date;

  constructor(
    private route: ActivatedRoute,
    private service: AppointmentsViewerService,
    private router: Router
  ) {
    this.currentDate = new Date();
    this.searchDateFrom = new Date();
    this.searchDateTo = new Date();
    this.fillCurrentWeek(this.currentDate);
  }

  public ngOnInit() {
    this.showCitaciones();
    this.setTimer();

  }
  setTimer(): any {
    const source = timer(600000);

    source.subscribe(val => this.redirectToSearch());
  }
  redirectToSearch(): void {
    this.router.navigate(['citaciones/']);
  }

  private showCitaciones() {
    let legajoParam: string;
    let tipoDocumentoParam: string;
    let documentoParam: string;

    this.route.queryParamMap.subscribe(params => {
      legajoParam = params.get('legajo');
      tipoDocumentoParam = params.get('tipodocumento');
      documentoParam = params.get('documento');
    });

    if (legajoParam && tipoDocumentoParam && documentoParam) {
      const searchFilter = new CitacionSearch();
      searchFilter.Legajo = legajoParam;
      searchFilter.TipoDocumento = tipoDocumentoParam;
      searchFilter.Documento = documentoParam;
      searchFilter.FechaDesde = this.searchDateFrom;
      searchFilter.FechaHasta = this.searchDateTo;

      this.service.getCitacionResult(searchFilter)
        .subscribe(
          (resp) => this.onSuccess(resp), (err) => this.onError(err)
        );
    }
  }

  public onError(err: any): void {
    console.error(err);
  }

  public onSuccess(response: CitacionResponse): void {
    this.viewModel = [];
    if (response.LegajoEmpleado > 0) {
      this.empleado = response.ApellidoEmpleado + ' ' + response.NombreEmpleado;
      this.legajo = response.LegajoEmpleado.toString();
      if (response.Citaciones.length > 0) {
        response.Citaciones.map((citacion) => {
          const model = new CitacionViewModel();
          model.Empleado = citacion.Empleado;
          model.Fecha = Moment(citacion.Fecha).format('DD-MM-YY');
          model.DiaDeLaSemana = Moment(citacion.Fecha).format('dddd');
          model.HorarioDesde = Moment(citacion.FechaHorarioDesde).format('ddd') + Moment(citacion.FechaHorarioDesde).format('LT');
          model.HorarioHasta = Moment(citacion.FechaHorarioHasta).format('ddd') + Moment(citacion.FechaHorarioHasta).format('LT');          
          model.Programa = citacion.Programa;
          model.Observaciones = citacion.Observaciones;

          if (citacion.FechaFueraOficinaDesde) {
            model.FueraOficinaDesde = `${Moment(citacion.FechaFueraOficinaDesde).format('ddd')} 
            ${Moment(citacion.FechaFueraOficinaDesde).format('LT')}`;
          }

        if (citacion.FechaFueraOficinaHasta) {
            model.FueraOficinaHasta = `${Moment(citacion.FechaFueraOficinaHasta).format('LT')} 
            ${Moment(citacion.FechaFueraOficinaHasta).format('ddd')}`;
          }

          this.viewModel.push(model);
        });
      }
    }
  }

  public fillCurrentWeek(date: Date) {
    this.startOfWeekStr = Moment(date)
      .startOf('isoWeek')
      .format('DD-MM');

    this.endOfWeekStr = Moment(date)
      .endOf('isoWeek')
      .format('DD-MM');

    this.searchDateFrom = Moment(date).startOf('isoWeek').toDate();
    this.searchDateTo = Moment(date).endOf('isoWeek').toDate();
  }

  public previousWeek_Click() {
    const lastWeek = Moment(this.currentDate)
      .add(-7, 'days')
      .toDate();

    this.currentDate = lastWeek;
    this.fillCurrentWeek(this.currentDate);
    this.showCitaciones();
  }

  public nextWeek_Click() {
    const nextWeek = Moment(this.currentDate)
      .add(7, 'days')
      .toDate();

    this.currentDate = nextWeek;
    this.fillCurrentWeek(this.currentDate);
    this.showCitaciones();
  }

  public closeSession() {
    this.router.navigate(['citaciones/']);
  }
}
