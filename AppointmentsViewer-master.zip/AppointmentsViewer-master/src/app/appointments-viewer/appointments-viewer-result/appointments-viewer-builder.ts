import { CitacionResult } from 'src/app/models/citacion/citacion.result';
import { CitacionViewModel } from 'src/app/models/citacion/citacion-view.model';
import * as Moment from 'moment';

export class ResultBuilder {

    public buildViewModel(citacionResult: CitacionResult[]): CitacionViewModel[] {

        const result: CitacionViewModel[] = [];

        citacionResult.forEach((citacion) => {
            const model = new CitacionViewModel();
            model.Fecha = Moment(citacion.Fecha).format('DD-MM-YY');
            model.HorarioDesde = Moment(citacion.Fecha).format('ddd') + Moment(citacion.Fecha).format('LT');
            model.HorarioHasta = Moment(citacion.Fecha).format('ddd') + Moment(citacion.Fecha).format('LT');
            model.Programa = citacion.Programa;
            model.Observaciones = citacion.Observaciones;

            if (citacion.FechaFueraOficinaDesde) {
                model.FueraOficinaDesde = `${Moment(citacion.FechaFueraOficinaDesde).format('ddd')} ${Moment(citacion.FechaFueraOficinaDesde).format('LT')}`;
              }
          
            if (citacion.FechaFueraOficinaHasta) {
                model.FueraOficinaHasta = `${Moment(citacion.FechaFueraOficinaHasta).format('LT')} ${Moment(citacion.FechaFueraOficinaHasta).format('ddd')}`;
              } 

            result.push(model);
        });

        return result;
    }
}
