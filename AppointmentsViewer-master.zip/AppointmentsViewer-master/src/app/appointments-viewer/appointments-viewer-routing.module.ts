import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppointmentsViewerSearchComponent } from './appointments-viewer-search/appointments-viewer-search.component';
import { AppointmentsViewerResultComponent } from './appointments-viewer-result/appointments-viewer-result.component';

const appointmentViewerRoutes: Routes = [
    {
        path: 'citaciones',
        redirectTo: '/citaciones'
    },
    {
        path: 'citacion',
        redirectTo: 'citacion'
    },
    {
        path: 'citaciones',
        component: AppointmentsViewerSearchComponent, data: { animation: 'citaciones' }
    },
    {
        path: 'citacion',
        component: AppointmentsViewerResultComponent, data: { animation: 'citacion' }
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(appointmentViewerRoutes)
    ],

    exports: [
        RouterModule
    ]
})

export class AppointmentsViewerRoutingModule { }
