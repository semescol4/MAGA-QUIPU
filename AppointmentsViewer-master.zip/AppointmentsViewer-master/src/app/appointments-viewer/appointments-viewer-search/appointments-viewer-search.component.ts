import { Router, NavigationExtras } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AppointmentsViewerService } from '../appointments-viewer-service';
import { EmpleadoSearch } from 'src/app/models/empleado/empleado.search';
import { Empleado } from 'src/app/models/empleado/empleado';
import { logging } from 'protractor';

@Component({
  selector: 'app-appointments-viewer-search',
  templateUrl: './appointments-viewer-search.component.html',
  styleUrls: ['./appointments-viewer-search.component.scss']
})

export class AppointmentsViewerSearchComponent implements OnInit {
  citacionForm: FormGroup;
  inputOk: boolean;

  constructor(
    private service: AppointmentsViewerService,
    private route: Router,
    private formBuilder: FormBuilder
  ) { }

  public ngOnInit(): void {
    this.createForm();
    this.resetInputOk();
  }

  private createForm(): void {
    this.citacionForm = this.formBuilder.group({
      tipoDocumento: ['DU',
        [Validators.required]
      ],
      documento: ['',
        [Validators.required, Validators.pattern(/^[a-zA-Z0-9]*$/)]
      ],
      legajo: ['',
        [Validators.required]
      ]
    });
  }

  public onSearchCitaciones_Click(): void {
    if (this.citacionForm.valid) {
      const empleadoSearch = new EmpleadoSearch();
      empleadoSearch.Legajo = this.legajo.value;
      empleadoSearch.TipoDocumento = this.tipoDocumento.value;
      empleadoSearch.Documento = this.documento.value;

      this.validateEmployeeAndNavigate(empleadoSearch);
    }
  }
  get legajo() {
    return this.citacionForm.get('legajo');
  }
  get tipoDocumento() {
    return this.citacionForm.get('tipoDocumento');
  }
  get documento() {
    return this.citacionForm.get('documento');
  }

  public resetInputOk() {
    if (this.legajo.valueChanges || this.documento.valueChanges || this.tipoDocumento.valueChanges) {
      this.inputOk = true;
    }
  }

  public validateEmployeeAndNavigate(empleadoSearch: EmpleadoSearch): void {

    this.service.getEmpleadoByPersonalData(empleadoSearch)
      .subscribe((resp) => this.onSuccess(resp), (err) => this.onError(err));
  }

  public onError(err: any): void {
    this.inputOk = false;
  }

  public onSuccess(result: Empleado): void {
    if (result.Legajo > 0) {
      const parameters: NavigationExtras = {
        queryParams: {
          'legajo': this.legajo.value,
          'tipodocumento': this.tipoDocumento.value,
          'documento': this.documento.value
        }
      };
      this.route.navigate(['citacion/'], parameters
      );
    } else {
      this.inputOk = false;
    }
  }
}
