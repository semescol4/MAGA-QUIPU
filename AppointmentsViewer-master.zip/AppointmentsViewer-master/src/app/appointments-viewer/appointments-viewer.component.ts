import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppointmentsViewerRoutingModule } from './appointments-viewer-routing.module';
import { AppointmentsViewerResultComponent } from './appointments-viewer-result/appointments-viewer-result.component';
import { AppointmentsViewerSearchComponent } from './appointments-viewer-search/appointments-viewer-search.component';
import { AppointmentsViewerService } from './appointments-viewer-service';
import { BrowserModule } from '@angular/platform-browser';
import { MaterialModule } from '../shared/material.module';


@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    AppointmentsViewerRoutingModule
  ],
  declarations: [
    AppointmentsViewerSearchComponent,
    AppointmentsViewerResultComponent
  ],
  providers: [
    AppointmentsViewerService
  ]
})

export class AppointmentsViewerComponent {
}
