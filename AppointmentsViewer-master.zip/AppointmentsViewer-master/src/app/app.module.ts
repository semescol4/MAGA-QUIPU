import { NgModule, LOCALE_ID } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

import { AppRoutingModule } from './app-routing.module';
import { AppointmentsViewerComponent } from './appointments-viewer/appointments-viewer.component';
import { AppointmentsViewerService } from './appointments-viewer/appointments-viewer-service';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppointmentsViewerComponent,
    AppRoutingModule,
    HttpModule,
    HttpClientModule
  ],
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  bootstrap: [
    AppComponent
  ],
  providers:
    [
      AppointmentsViewerService,
      { provide: LOCALE_ID, useValue: 'es-AR' }
    ]
})

export class AppModule {
}
