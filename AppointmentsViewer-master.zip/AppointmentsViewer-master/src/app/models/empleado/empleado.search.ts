export class EmpleadoSearch {
    Legajo: number;
    TipoDocumento: string;
    Documento: string;
}
