export class Empleado {
    Legajo: number;
    Id: number;
    Nombre: string;
    Apellido: string;
    NumeroCredencial: string;
    NumeroDocumento: string;
    TipoDocumento: string;
    FechaIngreso: Date;
    FechaEgreso: Date;
}
