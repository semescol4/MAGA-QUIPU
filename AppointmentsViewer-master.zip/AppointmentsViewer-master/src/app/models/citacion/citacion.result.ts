export class CitacionResult {
    Id: number;
    Empleado: string;
    Legajo: number;
    Fecha: Date;
    Programa: string;
    FechaHorarioDesde: Date;
    FechaHorarioHasta: Date;
    FechaFueraOficinaDesde: Date;
    FechaFueraOficinaHasta: Date;
    Observaciones: string;
}
