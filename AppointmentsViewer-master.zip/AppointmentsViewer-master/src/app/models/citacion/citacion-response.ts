import { CitacionResult } from './citacion.result';

export class CitacionResponse {
    ApellidoEmpleado: string;
    NombreEmpleado: string;
    LegajoEmpleado: number;
    Observaciones: string;
    Citaciones: Array<CitacionResult>;
}
