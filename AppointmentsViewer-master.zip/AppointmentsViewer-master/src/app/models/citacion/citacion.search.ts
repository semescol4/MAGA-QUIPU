export class CitacionSearch {
    Legajo: string;
    TipoDocumento: string;
    Documento: string;
    FechaDesde: Date;
    FechaHasta: Date;
}
