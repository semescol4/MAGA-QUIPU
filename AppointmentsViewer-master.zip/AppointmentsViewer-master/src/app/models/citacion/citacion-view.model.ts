export class CitacionViewModel {
    public Empleado: string;
    public Fecha: string;
    public DiaDeLaSemana: string;
    public HorarioDesde: string;
    public HorarioHasta: string;
    public Programa: string;
    public FueraOficinaDesde: string;
    public FueraOficinaHasta: string;
    public Observaciones: string;
}
