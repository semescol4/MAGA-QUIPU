import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AppointmentsViewerSearchComponent } from './appointments-viewer/appointments-viewer-search/appointments-viewer-search.component';
import { environment } from '../environments/environment';

const appRoutes: Routes = [
    { path: '', pathMatch: 'full', redirectTo: 'citaciones', },
    { path: 'index.html', pathMatch: 'full', redirectTo: 'citaciones', },
    { path: 'ClientApp/dist/citaciones', pathMatch: 'full', redirectTo: 'citaciones', },
    { path: 'citaciones', component: AppointmentsViewerSearchComponent, data: { animation: 'citaciones' } },
    { path: '**', component: PageNotFoundComponent },
];

@NgModule({
    imports: [
        RouterModule.forRoot(
            appRoutes,
            { enableTracing: environment.production ? true : false }
        )
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule {
}
