﻿namespace sgmo_conector_empleados;

public interface IAmericaPeruEmpleadoImporter
{
    Task Process();
}
