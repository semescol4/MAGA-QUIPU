﻿namespace sgmo_conector_empleados.SGMO.DTO;

public class EmpleadoSGMO
{
    public int Legajo { get; set; }
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public string CodigoEmpresa { get; set; }
    public string CodigoCentroCosto { get; set; }
    public string CodigoConvenio { get; set; }
    public string CodigoRegimen { get; set; }
    public string GrupoProfesionalA { get; set; }
    public string GrupoProfesionalB { get; set; }
    public string SubGrupoProfesional { get; set; }
    public string CodigoCentroTrabajo { get; set; }
    public DateTime FechaIngreso { get; set; }
    public DateTime FechaEgreso { get; set; }
    public bool Ficha { get; set; }
    public int UnidadOrganizativa { get; set; }
    public string NumeroCredencial { get; set; }
    public string FuncionRop { get; set; }
    public string TipoDocumento { get; set; }
    public string NumeroDocumento { get; set; }
    public string Cuit { get; set; }
    public DateTime FechaHastaContato { get; set; }
    public string TipoContrato { get; set; }
    public DateTime FechaDesdeContrato { get; set; }
    public string DescripcionUnidadOrganizativa { get; set; }
    public bool Externo { get; set; }
    public int LegajoSuperior { get; set; }
    public int LegajoVin { get; set; }
    public DateTime FechaAntiguedadVacaciones { get; set; }
    public string JobPositionCode { get; set; }
    public string CategoryCode { get; set; }
    public string SalaryScaleCode { get; set; }
}