﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using sgmo_conector_empleados.AmericaPeru.DTO;
using sgmo_conector_empleados.Services;
using sgmo_conector_empleados.SGMO.Services.Interfaces;
using System.Text.Json;

internal class SgmoWebApiConnector(ILogger<SgmoWebApiConnector> _logger, IConfiguration configuration, IHttpClientFactory httpClientFactory) : ISgmoWebApiConnector
{
    private const string SYNC_EMPLEADOS_PATH = "/api/empleado/empleadoSap";
    private const string EVICT_EMPLEADOS_PATH = "/api/CacheManager/EvictEmpleadosQueries";
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _url = configuration.GetValue<string>("SGMOApiUrl");
    private readonly int _timeout = configuration.GetValue<int>("SGMOApiUrl:TimeoutSeconds");

    public async Task Push(IEnumerable<EmpleadosResponseItem> items)
    {
        if (_logger.IsEnabled(LogLevel.Information))
            _logger.LogInformation("Push - Se mapean items: {0}", JsonSerializer.Serialize(items));

        var mappedItems = SgmoMapper.Map(items);

        if (_logger.IsEnabled(LogLevel.Information))
            _logger.LogInformation("Push - items mapeados: {0}", JsonSerializer.Serialize(mappedItems));

        var uriBuilder = new UriBuilder(_url)
        {
            Path = SYNC_EMPLEADOS_PATH
        };
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);

        ///api/empleado/empleadoSap
        await client.PostAsJsonAsync(uriBuilder.Uri, mappedItems);
    }

    public async Task EvictEmpleados()
    {
        var uriBuilder = new UriBuilder(_url)
        {
            Path = EVICT_EMPLEADOS_PATH
        };
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);

        var response = await client.PostAsync(uriBuilder.Uri, null);

        response.EnsureSuccessStatusCode();
    }
}