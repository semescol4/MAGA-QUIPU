﻿using sgmo_conector_empleados.AmericaPeru.DTO;

namespace sgmo_conector_empleados.SGMO.Services.Interfaces;

public interface ISgmoWebApiConnector
{
    Task EvictEmpleados();
    Task Push(IEnumerable<EmpleadosResponseItem> items);
}