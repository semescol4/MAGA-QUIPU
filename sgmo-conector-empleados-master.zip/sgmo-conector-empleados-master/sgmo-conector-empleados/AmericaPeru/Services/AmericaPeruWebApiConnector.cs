﻿using Microsoft.Extensions.Configuration;
using sgmo_conector_empleados.AmericaPeru.DTO;
using sgmo_conector_empleados.AmericaPeru.Services.Interfaces;
using System.Net.Http.Json;

namespace sgmo_conector_empleados.AmericaPeru.Services;

public class AmericaPeruWebApiConnector(IHttpClientFactory httpClientFactory, IConfiguration configuration) : IAmericaPeruWebApiConnector
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _urlTemplate = configuration.GetValue<string>("AmericaPeruApiUrl");
    private readonly int _timeout = configuration.GetValue<int>("AmericaPeruApiUrl:TimeoutSeconds");

    public async Task<EmpleadosResponseItem[]> GetEmployees(DateTime dateTime)
    {
        var url = string.Format(_urlTemplate, dateTime.ToString("dd-MM-yyyy"));
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);
        var empleadosResponse = await client.GetFromJsonAsync<EmpleadosResponse>(url);

        if (empleadosResponse == null)
            throw new Exception("No se pudo obtener la colección de empleados desde America Peru.");

        return empleadosResponse.items;
    }
}