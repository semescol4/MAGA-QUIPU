﻿using sgmo_conector_empleados.AmericaPeru.DTO;

namespace sgmo_conector_empleados.AmericaPeru.Services.Interfaces;

public interface IAmericaPeruWebApiConnector
{
    Task<EmpleadosResponseItem[]> GetEmployees(DateTime dateTime);
}