﻿// See https://aka.ms/new-console-template for more information
using System.Text.Json.Serialization;

namespace sgmo_conector_empleados.AmericaPeru.DTO;

public class EmpleadosResponseItem
{
    public string legajo { get; set; }
    public string first_name { get; set; }
    public string apellidos { get; set; }
    public string company { get; set; }
    public string ccosto { get; set; }
    public string cod_conv { get; set; }
    public string cod_reg { get; set; }
    public string jobcode_descr { get; set; }
    public string grp_prof_b { get; set; }
    public string sub_grp_prof { get; set; }
    public string cod_centrotrab { get; set; }
    public DateTime fec_ingreso { get; set; }
    public DateTime? fec_egreso { get; set; }
    public string ficha { get; set; }
    public string unid_org { get; set; }
    public string nro_credencial { get; set; }
    public int cod_sgmo { get; set; }
    public string tipo_doc { get; set; }
    public string nro_doc { get; set; }
    public string cuit { get; set; }
    public DateTime fec_desde_contr { get; set; }
    public DateTime? contract_end_dt { get; set; }
    [JsonPropertyName("contract_type||'-'||contract_type_desc")]
    public string contractType_Desc { get; set; }
    public string dept_descr { get; set; }
    public string externo { get; set; }
    public int legajo_sup { get; set; }
    public string legajo_vin { get; set; }
    public string fec_antig_vac { get; set; }
    public string jobcode { get; set; }
    public string category_cd { get; set; }
    public string salary_scale_cd { get; set; }
}