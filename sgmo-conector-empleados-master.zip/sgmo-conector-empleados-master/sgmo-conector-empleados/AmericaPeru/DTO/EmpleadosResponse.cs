﻿// See https://aka.ms/new-console-template for more information
namespace sgmo_conector_empleados.AmericaPeru.DTO;

public class EmpleadosResponse
{
    public EmpleadosResponseItem[] items { get; set; }
}
