﻿// See https://aka.ms/new-console-template for more information
using sgmo_conector_empleados.AmericaPeru.DTO;
using sgmo_conector_empleados.SGMO.DTO;

namespace sgmo_conector_empleados.Services;

public static class EmpleadosResponseItemMapper
{
    // Mapea de EmpleadosResponseItem a Empleado
    public static EmpleadoSGMO MapToEmpleado(EmpleadosResponseItem responseItem)
    {
        if (responseItem == null)
        {
            return null;
        }

        return new EmpleadoSGMO
        {
            Legajo = int.TryParse(responseItem.legajo, out int legajo) ? legajo : 0,
            Nombre = responseItem.first_name,
            Apellido = responseItem.apellidos,
            CodigoEmpresa = responseItem.company,
            CodigoCentroCosto = responseItem.ccosto,
            CodigoConvenio = responseItem.cod_conv,
            CodigoRegimen = responseItem.cod_reg,
            GrupoProfesionalA = responseItem.jobcode_descr,
            GrupoProfesionalB = responseItem.grp_prof_b,
            SubGrupoProfesional = responseItem.sub_grp_prof,
            CodigoCentroTrabajo = responseItem.cod_centrotrab,
            FechaIngreso = responseItem.fec_ingreso,
            FechaEgreso = responseItem.fec_egreso.GetValueOrDefault(),
            Ficha = responseItem.ficha == "Y",
            UnidadOrganizativa = int.TryParse(responseItem.unid_org, out int unidOrg) ? unidOrg : 0,
            NumeroCredencial = Convert.ToInt64(responseItem.nro_credencial).ToString(),
            TipoDocumento = responseItem.tipo_doc,
            NumeroDocumento = responseItem.nro_doc,
            Cuit = responseItem.cuit,
            FechaDesdeContrato = responseItem.fec_desde_contr,
            FechaHastaContato = responseItem.contract_end_dt.GetValueOrDefault(),
            TipoContrato = responseItem.contractType_Desc, // Ajustar según corresponda
            DescripcionUnidadOrganizativa = responseItem.dept_descr,
            Externo = responseItem.externo == "true",
            LegajoSuperior = responseItem.legajo_sup,
            LegajoVin = int.TryParse(responseItem.legajo_vin, out int legajoVin) ? legajoVin : 0,
            FechaAntiguedadVacaciones = DateTime.TryParse(responseItem.fec_antig_vac, out DateTime fecAntigVac) ? fecAntigVac : default,
            JobPositionCode = responseItem.jobcode,
            CategoryCode = responseItem.category_cd,
            SalaryScaleCode = responseItem.salary_scale_cd,

            FuncionRop = responseItem.cod_sgmo.ToString()
        };
    }
}