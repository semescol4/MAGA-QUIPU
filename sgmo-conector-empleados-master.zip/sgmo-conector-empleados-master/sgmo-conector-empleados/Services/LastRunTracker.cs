﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace sgmo_conector_empleados.Services;

public class LastRunTracker(ILogger<LastRunTracker> _logger, IConfiguration _configuration) : ILastRunTracker
{
    private const string FILEDATEFORMAT = "dd-MM-yyyy";
    private readonly string _lastRunTrackFile = _configuration.GetValue<string>("LastRunTrackFile");

    public async Task<DateTime> GetFechaDesdeASincronizar()
    {
        _logger.LogInformation("GetFechaDesdeASincronizar - Obteniendo fecha a sincronizar.");
        if (!File.Exists(_lastRunTrackFile))
        {
            var minimumDate = GetFormattedForLogDate(DateTime.MinValue);

            File.WriteAllText(_lastRunTrackFile, minimumDate);
        }

        var readFromFile = await File.ReadAllTextAsync(_lastRunTrackFile);
        var lastRunDateTime = DateTime.ParseExact(readFromFile, FILEDATEFORMAT, null);

        _logger.LogInformation("GetFechaDesdeASincronizar - fecha a sincronizar: {0}", lastRunDateTime);

        return lastRunDateTime;
    }

    private static string GetFormattedForLogDate(DateTime aDateTime)
    {
        return aDateTime.ToString(FILEDATEFORMAT);
    }

    public async Task SaveFechaEjecucion()
    {
        var lastRunDateTime = DateTime.Now;
        var lastRunDateTimeToFile = GetFormattedForLogDate(lastRunDateTime);

        await File.WriteAllTextAsync(_lastRunTrackFile, lastRunDateTimeToFile);

        _logger.LogInformation("SaveFechaEjecucion - Se guardó nueva fecha: {0}", lastRunDateTimeToFile);
    }
}