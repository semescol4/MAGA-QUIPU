﻿// See https://aka.ms/new-console-template for more information

using sgmo_conector_empleados.AmericaPeru.DTO;
using sgmo_conector_empleados.SGMO.DTO;

namespace sgmo_conector_empleados.Services;

internal class SgmoMapper
{
    internal static IEnumerable<EmpleadoSGMO> Map(IEnumerable<EmpleadosResponseItem> empleadosFromAmericaPeru)
    {
        var empleadosSgmo = empleadosFromAmericaPeru.Select(EmpleadosResponseItemMapper.MapToEmpleado);

        return empleadosSgmo.ToList();
    }
}