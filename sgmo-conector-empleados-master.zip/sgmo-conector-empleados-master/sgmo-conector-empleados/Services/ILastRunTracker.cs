﻿namespace sgmo_conector_empleados.Services;

public interface ILastRunTracker
{
    Task<DateTime> GetFechaDesdeASincronizar();
    Task SaveFechaEjecucion();
}