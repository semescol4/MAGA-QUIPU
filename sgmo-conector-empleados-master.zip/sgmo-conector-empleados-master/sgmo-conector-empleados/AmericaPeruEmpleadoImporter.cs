﻿using Microsoft.Extensions.Logging;
using sgmo_conector_empleados.AmericaPeru.Services.Interfaces;
using sgmo_conector_empleados.Services;
using sgmo_conector_empleados.SGMO.Services.Interfaces;

namespace sgmo_conector_empleados;

public class AmericaPeruEmpleadoImporter(ILogger<AmericaPeruEmpleadoImporter> _logger, ILastRunTracker lastRunTracker, IAmericaPeruWebApiConnector americaPeruWebApiConnector, ISgmoWebApiConnector sgmoWebApiConnector) : IAmericaPeruEmpleadoImporter
{
    private readonly ILastRunTracker _lastRunTracker = lastRunTracker;
    private readonly IAmericaPeruWebApiConnector _americaPeruWebApiConnector = americaPeruWebApiConnector;
    private readonly ISgmoWebApiConnector _sgmoWebApiConnector = sgmoWebApiConnector;

    public async Task Process()
    {
        var fechaDesdeASincronizar = await _lastRunTracker.GetFechaDesdeASincronizar();

        _logger.LogInformation("Process - Fecha Desde a utilizar: {0}", fechaDesdeASincronizar);

        _logger.LogInformation("Process - Obteniendo empleados.");

        var items = await _americaPeruWebApiConnector.GetEmployees(fechaDesdeASincronizar);

        if (items.Length > 0)
        {
            _logger.LogInformation("Process - Hay items, se actualizan empleados en sgmo.");

            await _sgmoWebApiConnector.Push(items);

            _logger.LogInformation("Process - se invalida cache de empleados.");

            await _sgmoWebApiConnector.EvictEmpleados();
        }

        _logger.LogInformation("Process - se guarda nueva fecha de ejecución.");
        await _lastRunTracker.SaveFechaEjecucion();
    }
}
