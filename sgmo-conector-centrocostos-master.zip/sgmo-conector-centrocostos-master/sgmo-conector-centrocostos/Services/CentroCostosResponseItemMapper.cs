﻿// See https://aka.ms/new-console-template for more information
using sgmo_conector_centrocostos.AmericaPeru.DTO;
using sgmo_conector_centrocostos.SGMO.DTO;
using System.Globalization;

namespace sgmo_conector_centrocostos.Services;

public static class CentroCostosResponseItemMapper
{
    public static CentroCostoSGMO Map(CentroCostosResponseItem responseItem)
    {
        if (responseItem == null)
        {
            return null;
        }

        return new CentroCostoSGMO
        {
            Descripcion = responseItem.descripcion,
            Codigo = responseItem.codigo,
            FechaDesdeValida = responseItem.fechadesdevalida is null ? null : DateTime.Parse(responseItem.fechadesdevalida, CultureInfo.GetCultureInfo("en-GB")),
            FechaHastaValida = responseItem.fechahastavalida is null ? null : DateTime.Parse(responseItem.fechahastavalida, CultureInfo.GetCultureInfo("en-GB")),
            CodigoMoneda = responseItem.codigomoneda,
            FechaAlta = DateTime.Parse(responseItem.fechaalta, CultureInfo.GetCultureInfo("en-GB")),
            CodigoCompania = responseItem.codigocompania,

            AreaFuncional = null,
            CentroBeneficio = null,
            LineaDeTrabajo = null,
            UsuarioAlta = "SGMO",
            UsuarioModificacion = "SGMO",
            FechaModificacion = DateTime.Now,
        };
    }
}