﻿// See https://aka.ms/new-console-template for more information

using sgmo_conector_centrocostos.AmericaPeru.DTO;
using sgmo_conector_centrocostos.SGMO.DTO;

namespace sgmo_conector_centrocostos.Services;

internal class SgmoMapper
{
    internal static IEnumerable<CentroCostoSGMO> Map(IEnumerable<CentroCostosResponseItem> centroCostosFromAmericaPeru)
    {
        var centroCostoSGMO = centroCostosFromAmericaPeru.Select(CentroCostosResponseItemMapper.Map);

        return centroCostoSGMO.ToList();
    }
}