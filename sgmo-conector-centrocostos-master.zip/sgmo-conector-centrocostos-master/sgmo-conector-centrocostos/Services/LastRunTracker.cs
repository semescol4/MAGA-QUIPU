﻿using Microsoft.Extensions.Configuration;

namespace sgmo_conector_centrocostos.Services;

public class LastRunTracker(IConfiguration configuration) : ILastRunTracker
{
    private const string FILEDATEFORMAT = "dd-MM-yyyy";
    private readonly string _lastRunTrackFile = configuration.GetValue<string>("LastRunTrackFile");

    public async Task<DateTime> GetFechaDesdeASincronizar()
    {
        if (!File.Exists(_lastRunTrackFile))
        {
            var minimumDate = GetFormattedForLogDate(DateTime.MinValue);

            File.WriteAllText(_lastRunTrackFile, minimumDate);
        }

        var readFromFile = await File.ReadAllTextAsync(_lastRunTrackFile);
        var lastRunDateTime = DateTime.ParseExact(readFromFile, FILEDATEFORMAT, null);

        return lastRunDateTime;
    }

    private static string GetFormattedForLogDate(DateTime aDateTime)
    {
        return aDateTime.ToString(FILEDATEFORMAT);
    }

    public async Task SaveFechaEjecucion()
    {
        var lastRunDateTime = DateTime.Now;
        var lastRunDateTimeToFile = GetFormattedForLogDate(lastRunDateTime);

        await File.WriteAllTextAsync(_lastRunTrackFile, lastRunDateTimeToFile);
    }
}