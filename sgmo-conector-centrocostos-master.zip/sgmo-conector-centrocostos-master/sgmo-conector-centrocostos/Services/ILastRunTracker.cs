﻿namespace sgmo_conector_centrocostos.Services;

public interface ILastRunTracker
{
    Task<DateTime> GetFechaDesdeASincronizar();
    Task SaveFechaEjecucion();
}