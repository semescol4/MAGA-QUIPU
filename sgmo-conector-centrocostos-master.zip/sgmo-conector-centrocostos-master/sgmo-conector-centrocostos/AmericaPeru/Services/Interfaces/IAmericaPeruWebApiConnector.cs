﻿using sgmo_conector_centrocostos.AmericaPeru.DTO;

namespace sgmo_conector_centrocostos.AmericaPeru.Services.Interfaces;

public interface IAmericaPeruWebApiConnector
{
    Task<CentroCostosResponseItem[]> GetCostCenters(DateTime dateTime);
}