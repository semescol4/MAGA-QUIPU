﻿// See https://aka.ms/new-console-template for more information
namespace sgmo_conector_centrocostos.AmericaPeru.DTO;

public class CentroCostosResponseItem
{
    public string descripcion { get; set; }
    public string fechadesdevalida { get; set; }
    public string fechahastavalida { get; set; }
    public string codigocompania { get; set; }
    public string codigomoneda { get; set; }
    public string codigo { get; set; }
    public string fechaalta { get; set; }
}