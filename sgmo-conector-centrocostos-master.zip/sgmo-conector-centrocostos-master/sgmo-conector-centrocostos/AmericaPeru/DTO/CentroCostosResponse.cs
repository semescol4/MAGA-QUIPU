﻿// See https://aka.ms/new-console-template for more information
namespace sgmo_conector_centrocostos.AmericaPeru.DTO;

public class CentroCostosResponse
{
    public CentroCostosResponseItem[] items { get; set; }
}
