﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using sgmo_conector_centrocostos;
using sgmo_conector_centrocostos.AmericaPeru.Services;
using sgmo_conector_centrocostos.AmericaPeru.Services.Interfaces;
using sgmo_conector_centrocostos.Services;
using sgmo_conector_centrocostos.SGMO.Services.Interfaces;

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .AddCommandLine(args)
    .Build();

var serviceProvider = new ServiceCollection()
    .AddLogging(config =>
        {
            config.AddConfiguration(configuration.GetSection("Logging"));
            config.AddConsole(c =>
            {
                c.TimestampFormat = "[HH:mm:ss.fff] ";
            });
        })
    .AddSingleton<IConfiguration>(configuration)
    .AddSingleton<ILastRunTracker, LastRunTracker>()
    .AddSingleton<IAmericaPeruWebApiConnector, AmericaPeruWebApiConnector>()
    .AddSingleton<ISgmoWebApiConnector, SgmoWebApiConnector>()
    .AddSingleton<IAmericaPeruCentroCostoImporter, AmericaPeruCentroCostoImporter>()
    .AddHttpClient()
    .BuildServiceProvider();

using (serviceProvider)
{
    var importer = serviceProvider.GetRequiredService<IAmericaPeruCentroCostoImporter>();

    await importer.Process();
}