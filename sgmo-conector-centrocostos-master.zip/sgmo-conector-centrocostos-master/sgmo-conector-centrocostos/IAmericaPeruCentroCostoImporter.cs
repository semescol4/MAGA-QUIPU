﻿namespace sgmo_conector_centrocostos;

public interface IAmericaPeruCentroCostoImporter
{
    Task Process();
}
