﻿namespace sgmo_conector_centrocostos.SGMO.DTO;

public class CentroCostoSGMO
{
    public string Descripcion { get; set; }
    public DateTime? FechaDesdeValida { get; set; }
    public DateTime? FechaHastaValida { get; set; }
    public string CodigoCompania { get; set; }
    public string CodigoMoneda { get; set; }
    public string CentroBeneficio { get; set; }
    public string AreaFuncional { get; set; }
    public string LineaDeTrabajo { get; set; }
    public string Codigo { get; set; }
    public string UsuarioAlta { get; set; }
    public DateTime FechaAlta { get; set; }
    public string? UsuarioModificacion { get; set; }
    public DateTime? FechaModificacion { get; set; }
}