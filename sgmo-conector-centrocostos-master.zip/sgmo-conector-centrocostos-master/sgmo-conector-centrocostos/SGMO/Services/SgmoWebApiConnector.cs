﻿using Microsoft.Extensions.Configuration;
using sgmo_conector_centrocostos.AmericaPeru.DTO;
using sgmo_conector_centrocostos.Services;
using sgmo_conector_centrocostos.SGMO.Services.Interfaces;

internal class SgmoWebApiConnector(IConfiguration configuration, IHttpClientFactory httpClientFactory) : ISgmoWebApiConnector
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _url = configuration.GetValue<string>("SGMOApiUrl");
    private readonly int _timeout = configuration.GetValue<int>("SGMOApiUrl:TimeoutSeconds");

    public async Task Push(IEnumerable<CentroCostosResponseItem> items)
    {
        var mappedItems = SgmoMapper.Map(items);

        var uri = new Uri(_url);
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);

        var response = await client.PostAsJsonAsync(uri, mappedItems);
        response.EnsureSuccessStatusCode();
    }
}