﻿using sgmo_conector_centrocostos.AmericaPeru.DTO;

namespace sgmo_conector_centrocostos.SGMO.Services.Interfaces;

public interface ISgmoWebApiConnector
{
    Task Push(IEnumerable<CentroCostosResponseItem> items);
}