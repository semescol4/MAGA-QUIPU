﻿using sgmo_conector_centrocostos.AmericaPeru.Services.Interfaces;
using sgmo_conector_centrocostos.Services;
using sgmo_conector_centrocostos.SGMO.Services.Interfaces;

namespace sgmo_conector_centrocostos;

public class AmericaPeruCentroCostoImporter(ILastRunTracker lastRunTracker, IAmericaPeruWebApiConnector americaPeruWebApiConnector, ISgmoWebApiConnector sgmoWebApiConnector) : IAmericaPeruCentroCostoImporter
{
    private readonly ILastRunTracker _lastRunTracker = lastRunTracker;
    private readonly IAmericaPeruWebApiConnector _americaPeruWebApiConnector = americaPeruWebApiConnector;
    private readonly ISgmoWebApiConnector _sgmoWebApiConnector = sgmoWebApiConnector;

    public async Task Process()
    {
        var fechaDesdeASincronizar = await _lastRunTracker.GetFechaDesdeASincronizar();

        var items = await _americaPeruWebApiConnector.GetCostCenters(fechaDesdeASincronizar);

        if (items.Length > 0)
            await _sgmoWebApiConnector.Push(items);

        await _lastRunTracker.SaveFechaEjecucion();
    }
}
