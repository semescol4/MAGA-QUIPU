﻿using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.AmericaPeru.Services.Interfaces;
using sgmo_conector_relojes.Services;
using sgmo_conector_relojes.SGMO.Services.Interfaces;

namespace sgmo_conector_relojes;

public class AmericaPeruMarcajeImporter(ILogger<AmericaPeruMarcajeImporter> logger, ILastRunTracker lastRunTracker, IAmericaPeruWebApiConnector americaPeruWebApiConnector, ISgmoWebApiConnector sgmoWebApiConnector) : IAmericaPeruMarcajeImporter
{
    private readonly ILastRunTracker _lastRunTracker = lastRunTracker;
    private readonly IAmericaPeruWebApiConnector _americaPeruWebApiConnector = americaPeruWebApiConnector;
    private readonly ISgmoWebApiConnector _sgmoWebApiConnector = sgmoWebApiConnector;
    private readonly ILogger<AmericaPeruMarcajeImporter> _logger = logger;

    public async Task Process()
    {
        var fechaDesdeASincronizar = await _lastRunTracker.GetFechaDesdeASincronizar();

        _logger.LogInformation("Iniciando proceso con fecha {fechaDesdeASincronizar}.", fechaDesdeASincronizar);

        var items = await _americaPeruWebApiConnector.GetMarcajesForDate(fechaDesdeASincronizar);

        if (items.Length > 0)
            await _sgmoWebApiConnector.ImportFichadasReloj(items, fechaDesdeASincronizar);

        fechaDesdeASincronizar = fechaDesdeASincronizar.AddDays(1);

        await _lastRunTracker.SaveFechaEjecucion(fechaDesdeASincronizar);
    }
}
