﻿using sgmo_conector_relojes.AmericaPeru.DTO;

namespace sgmo_conector_relojes.SGMO.Services.Interfaces;

public interface ISgmoWebApiConnector
{
    Task ImportFichadasReloj(IEnumerable<MarcajeItem> items, DateTime fechaEjecucion);
}