﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.AmericaPeru.DTO;
using sgmo_conector_relojes.Services;
using sgmo_conector_relojes.SGMO.DTO;
using sgmo_conector_relojes.SGMO.Services.Interfaces;
using System.Net.Http.Json;

internal class SgmoWebApiConnector(ILogger<SgmoWebApiConnector> _logger, IConfiguration configuration, IHttpClientFactory httpClientFactory) : ISgmoWebApiConnector
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _url = configuration.GetValue<string>("SGMOApiUrl") ?? throw new Exception("Debe agregar la setting: SGMOApiUrl.");
    private readonly string _urlImportarFichadasReloj = "/api/Fichada";
    private readonly int _timeout = configuration.GetValue<int>("SGMOApiUrl:TimeoutSeconds");

    public async Task ImportFichadasReloj(IEnumerable<MarcajeItem> items, DateTime fechaEjecucion)
    {
        _logger.LogInformation($"ImportFichadasReloj - Obteniendo Citaciones.");

        var citacionesDiccionario = await ObtenerCitaciones(fechaEjecucion);

        _logger.LogInformation($"ImportFichadasReloj - Se inicia mapeo de marcajes a Fichadas Sgmo.");

        var fichadasSGMO = SgmoMapper.Map(items, citacionesDiccionario, _logger);

        _logger.LogInformation($"ImportFichadasReloj - Fin mapeo. Se mapearon {fichadasSGMO.Count()} marcajes a fichadas SGMO.");

        //_logger.LogInformation($"ImportFichadasReloj - Se completan marcajes del día anterior sin sentido.");

        //await CompletarSalidasPrevias(fichadasSGMO, fechaEjecucion);

        _logger.LogInformation($"ImportFichadasReloj - Se envían las fichadas con sentido a SGMO.");

        var fichadasConSentido = fichadasSGMO.Where(x => x.TieneSentido()).ToList();

        _logger.LogInformation($"ImportFichadasReloj - De {fichadasSGMO.Count()} fichadas SGMO, se envían {fichadasConSentido.Count} fichadas SGMO con sentido.");

        await EnviarASgmo(fichadasConSentido);
    }

    private async Task EnviarASgmo(IEnumerable<FichadaSGMO> mappedItems)
    {
        var uri = new Uri(_url);
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);
        client.BaseAddress = uri;

        var response = await client.PostAsJsonAsync(_urlImportarFichadasReloj, mappedItems);

        response.EnsureSuccessStatusCode();
    }

    private async Task<IDictionary<long, EmployeeMinMaxCitadaDTO>> ObtenerCitaciones(DateTime fechaEjecucion)
    {
        var citaciones = await GetAllCitaciones(fechaEjecucion);
        var citacionesDiccionario = citaciones.ToDictionary(x => x.Legajo);

        return citacionesDiccionario;
    }

    //private async Task CompletarSalidasPrevias(IEnumerable<FichadaSGMO> mappedItems, DateTime fechaEjecucion)
    //{
    //    var fechaCitadasCompletar = fechaEjecucion.AddDays(-1);

    //    var citacionesDiccionario = await ObtenerCitaciones(fechaCitadasCompletar);

    //     _logger.LogInformation($"CompletarSalidasPrevias - Se obtuvieron {citacionesDiccionario.Count} citaciones con fecha {fechaCitadasCompletar}.");

    //     _logger.LogInformation($"CompletarSalidasPrevias - Inicio actualización de estados para fichadas previas.");

    //    foreach (var fichadaSgmo in ObtenerFichadasSgmoSinSentido(mappedItems))
    //    {
    //        fichadaSgmo.UpdateDirectionAndState(citacionesDiccionario);
    //    }

    //     _logger.LogInformation($"CompletarSalidasPrevias - Fin actualización de estados para fichadas previas.");
    //}

    //private static IEnumerable<FichadaSGMO> ObtenerFichadasSgmoSinSentido(IEnumerable<FichadaSGMO> mappedItems)
    //{
    //    return mappedItems.Where(x => !x.TieneSentido());
    //}

    private async Task<IList<EmployeeMinMaxCitadaDTO>> GetAllCitaciones(DateTime date)
    {
        var uri = new Uri(_url);
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);
        client.BaseAddress = uri;
        var path = $"/api/Citaciones/AggregatedByDateEmployee?date={date:MM-dd-yyyy}&incluirLicencias=false";

        var result = await client.GetFromJsonAsync<List<EmployeeMinMaxCitadaDTO>>(path);

        return result!;
    }
}
