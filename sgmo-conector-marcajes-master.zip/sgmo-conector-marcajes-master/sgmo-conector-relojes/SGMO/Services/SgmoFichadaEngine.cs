﻿using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.SGMO.DTO;

namespace sgmo_conector_relojes.SGMO.Services;

public static class SgmoFichadaExtensions
{
    private const string MARCAJE_ESTADO_NOPROCESADO = "0";
    private const string MARCAJE_ESTADO_SENTIDOINVALIDO = "4";
    private const double BUFFER_HOURS = 2.5;

    private static string ObtenerEstadoMarcaje(string entradaSalida)
    {
        var marcajeEstadoCalculado = MARCAJE_ESTADO_NOPROCESADO;

        if (entradaSalida == string.Empty)
        {
            marcajeEstadoCalculado = MARCAJE_ESTADO_SENTIDOINVALIDO;
        }

        return marcajeEstadoCalculado;
    }

    private static string ObtenerEntradaSalida(FichadaSGMO fichada, IDictionary<long, EmployeeMinMaxCitadaDTO> citaciones)
    {
        var legajo = fichada.Legajo;
        if (!citaciones.TryGetValue(legajo, out EmployeeMinMaxCitadaDTO? citacion)) return string.Empty;

        var fecha = fichada.Fecha;
        var bufferedFrom1 = citacion.FechaHorarioDesde.AddHours(-BUFFER_HOURS);
        var bufferedFrom2 = citacion.FechaHorarioDesde.AddHours(BUFFER_HOURS);

        var bufferedTo1 = citacion.FechaHorarioHasta.AddHours(-BUFFER_HOURS);
        var bufferedTo2 = citacion.FechaHorarioHasta.AddHours(BUFFER_HOURS);

        var entradaSalida = string.Empty;

        if (Between(fecha, bufferedFrom1, bufferedFrom2))
            entradaSalida = "Entrada";

        if (Between(fecha, bufferedTo1, bufferedTo2))
            entradaSalida = "Salida";

        return entradaSalida;
    }

    static bool Between(DateTime input, DateTime date1, DateTime date2)
    {
        return input > date1 && input < date2;
    }

    public static void UpdateDirectionAndState(this FichadaSGMO fichadaSgmo, IDictionary<long, EmployeeMinMaxCitadaDTO> citaciones, ILogger logger)
    {
        var entradaSalida = ObtenerEntradaSalida(fichadaSgmo, citaciones);
        var estadoMarcajeCalculado = ObtenerEstadoMarcaje(entradaSalida);

        fichadaSgmo.Sentido = entradaSalida;
        fichadaSgmo.Estado = estadoMarcajeCalculado;

        logger.LogInformation($"Se procesa legajo {fichadaSgmo.Legajo}. Fecha: {fichadaSgmo.Fecha}. Entradasalida calculado: {fichadaSgmo.Sentido}. Estado calculado: {fichadaSgmo.Estado}.");
    }
}