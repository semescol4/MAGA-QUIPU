﻿public class EmployeeMinMaxCitadaDTO
{
    public long Legajo { get; set; }
    public DateTime FechaHorarioDesde { get; set; }
    public DateTime FechaHorarioHasta { get; set; }
}