﻿namespace sgmo_conector_relojes.SGMO.DTO;
using System;
using System.Text.Json.Serialization;

public class FichadaSGMO
{
    [JsonPropertyName("Credencial")]
    public string? Credencial { get; set; }

    [JsonPropertyName("CodReloj")]
    public string? CodReloj { get; set; }

    [JsonPropertyName("Fecha")]
    public DateTime Fecha { get; set; }

    [JsonPropertyName("Sentido")]
    public string? Sentido { get; set; }

    [JsonPropertyName("Usuario")]
    public string? Usuario { get; set; }

    [JsonPropertyName("Legajo")]
    public int Legajo { get; set; }

    [JsonPropertyName("JournalId")]
    public int JournalId { get; set; }

    [JsonPropertyName("Estado")]
    public string? Estado { get; set; }

    public bool TieneSentido() => Sentido != string.Empty;
}
