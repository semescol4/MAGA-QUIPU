﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using sgmo_conector_relojes;
using sgmo_conector_relojes.AmericaPeru.Services;
using sgmo_conector_relojes.AmericaPeru.Services.Interfaces;
using sgmo_conector_relojes.Services;
using sgmo_conector_relojes.SGMO.Services.Interfaces;

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .AddCommandLine(args)
    .Build();

Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();

var serviceProvider = new ServiceCollection()
    .AddLogging(config =>
        {
            config.AddConfiguration(configuration.GetSection("Logging"));
            config.AddSerilog(Log.Logger, true);
        })
    .AddSingleton<IConfiguration>(configuration)
    .AddSingleton<ILastRunTracker, LastRunTracker>()
    .AddSingleton<IAmericaPeruWebApiConnector, AmericaPeruWebApiConnector>()
    .AddSingleton<ISgmoWebApiConnector, SgmoWebApiConnector>()
    .AddSingleton<IAmericaPeruMarcajeImporter, AmericaPeruMarcajeImporter>()
    .AddHttpClient()
    .BuildServiceProvider();

using (serviceProvider)
{
    var importer = serviceProvider.GetRequiredService<IAmericaPeruMarcajeImporter>();
    var logger = serviceProvider.GetRequiredService<ILogger<Program>>();

    try
    {
        await importer.Process();
    }
    catch (Exception ex)
    {
        logger.LogError(ex, message: "Excepción.");
        Environment.ExitCode = 1;

        throw;
    }
}