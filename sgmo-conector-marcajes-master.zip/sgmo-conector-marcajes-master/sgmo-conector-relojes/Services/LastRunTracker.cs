﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace sgmo_conector_relojes.Services;

public class LastRunTracker(ILogger<LastRunTracker> logger, IConfiguration configuration) : ILastRunTracker
{
    private const string FILEDATEFORMAT = "dd-MM-yyyy";
    private readonly string _lastRunTrackFile = configuration.GetValue<string>("LastRunTrackFile")!;
    private readonly ILogger<LastRunTracker> _logger = logger;

    /// <summary>
    /// Devuelve la fecha desde la que sincronizar. Como es a día vencido, devuelve la fecha guardada -1 día.
    /// </summary>
    /// <returns></returns>
    public async Task<DateTime> GetFechaDesdeASincronizar()
    {
        if (!File.Exists(_lastRunTrackFile))
        {
            var minimumDate = GetFormattedForLogDate(new DateTime(2024, 1, 1));

            File.WriteAllText(_lastRunTrackFile, minimumDate);
        }

        var readFromFile = await File.ReadAllTextAsync(_lastRunTrackFile);
        var lastRunDateTime = DateTime.ParseExact(readFromFile, FILEDATEFORMAT, null);

        _logger.LogInformation("Se inicia ejecución con fecha {lastRunDateTime}.", lastRunDateTime);

        return lastRunDateTime;
    }

    private static string GetFormattedForLogDate(DateTime aDateTime)
    {
        return aDateTime.ToString(FILEDATEFORMAT);
    }

    public async Task SaveFechaEjecucion(DateTime lastRunDateTime)
    {
        var lastRunDateTimeToFile = GetFormattedForLogDate(lastRunDateTime);

        _logger.LogInformation("Se guarda ejecución con fecha {lastRunDateTime}.", lastRunDateTime);

        await File.WriteAllTextAsync(_lastRunTrackFile, lastRunDateTimeToFile);
    }
}