﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.AmericaPeru.DTO;
using sgmo_conector_relojes.AmericaPeru.DTO.Extensions;
using sgmo_conector_relojes.SGMO.DTO;
using sgmo_conector_relojes.SGMO.Services;

namespace sgmo_conector_relojes.Services;

public static class MarcajeItemMapper
{
    public static FichadaSGMO Map(MarcajeItem item, IDictionary<long, EmployeeMinMaxCitadaDTO> citaciones, ILogger logger)
    {
        if (item.JournalId is null)
        {
            throw new ArgumentNullException(nameof(item), $"La propiedad {nameof(item.JournalId)} no puede ser nula.");
        }

        var fichadaSgmo = new FichadaSGMO
        {
            Credencial = item.NroTarjetaEtb,
            CodReloj = item.CodReloj,
            Fecha = item.GetParsedKznMrcRlj(),
            Legajo = Convert.ToInt32(item.NroTarjetaEtb),
            JournalId = int.Parse(item.JournalId),
            Usuario = "SGMO"
        };

        fichadaSgmo.UpdateDirectionAndState(citaciones, logger);

        return fichadaSgmo;
    }
}