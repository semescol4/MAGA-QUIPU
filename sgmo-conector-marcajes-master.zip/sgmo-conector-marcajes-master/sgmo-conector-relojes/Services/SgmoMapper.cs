﻿// See https://aka.ms/new-console-template for more information

using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.AmericaPeru.DTO;
using sgmo_conector_relojes.SGMO.DTO;

namespace sgmo_conector_relojes.Services;

internal class SgmoMapper
{
    internal static IEnumerable<FichadaSGMO> Map(IEnumerable<MarcajeItem> marcajesFromAmericaPeru, IDictionary<long, EmployeeMinMaxCitadaDTO> citaciones, ILogger logger)
    {
        var marcajeSGMO = marcajesFromAmericaPeru.Select(x => MarcajeItemMapper.Map(x, citaciones, logger));

        return marcajeSGMO.ToList();
    }
}