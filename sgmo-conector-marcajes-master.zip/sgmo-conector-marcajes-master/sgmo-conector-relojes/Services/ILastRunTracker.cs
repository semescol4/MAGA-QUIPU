﻿namespace sgmo_conector_relojes.Services;

public interface ILastRunTracker
{
    Task<DateTime> GetFechaDesdeASincronizar();
    Task SaveFechaEjecucion(DateTime fechaDesdeASincronizar);
}