﻿namespace sgmo_conector_relojes;

public interface IAmericaPeruMarcajeImporter
{
    Task Process();
}
