﻿// See https://aka.ms/new-console-template for more information
namespace sgmo_conector_relojes.AmericaPeru.DTO.Extensions;

public static class MarcajeItemExtensions
{
    public static DateTime GetParsedKznMrcRlj(this MarcajeItem obj)
    {
        if (obj.KznMrcRlj is null)
        {
            throw new ArgumentNullException(nameof(obj), $"La propiedad {nameof(obj.KznMrcRlj)} no puede ser nula.");
        }

        var fecha = DateTime.ParseExact(obj.KznMrcRlj, "dd-MM-yyyy HH:mm:ss", null);

        return fecha;
    }
}