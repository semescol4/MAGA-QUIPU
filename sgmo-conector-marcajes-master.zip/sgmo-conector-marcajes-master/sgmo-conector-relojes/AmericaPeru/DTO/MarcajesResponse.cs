﻿// See https://aka.ms/new-console-template for more information
using System.Text.Json.Serialization;

namespace sgmo_conector_relojes.AmericaPeru.DTO;

public class MarcajesResponse
{
    [JsonPropertyName("items")]
    public MarcajeItem[] Items { get; set; } = [];
}
