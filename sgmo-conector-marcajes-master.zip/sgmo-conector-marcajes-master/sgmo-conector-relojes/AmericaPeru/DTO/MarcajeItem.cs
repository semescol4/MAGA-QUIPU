﻿// See https://aka.ms/new-console-template for more information
namespace sgmo_conector_relojes.AmericaPeru.DTO;

using System.Text.Json.Serialization;

public class MarcajeItem
{
    [JsonPropertyName("cpr_clave_unica")]
    public string? CprClaveUnica { get; set; }

    [JsonPropertyName("credencial")]
    public string? Credencial { get; set; }

    [JsonPropertyName("codreloj")]
    public string? CodReloj { get; set; }

    [JsonPropertyName("kzn_mrc_rlj")]
    public string? KznMrcRlj { get; set; }

    [JsonPropertyName("sentido")]
    public string? Sentido { get; set; }

    [JsonPropertyName("nro_tarjeta_etb")]
    public string? NroTarjetaEtb { get; set; }

    [JsonPropertyName("legajo")]
    public int Legajo { get; set; }

    [JsonPropertyName("journal_id")]
    public string? JournalId { get; set; }

    [JsonPropertyName("estado")]
    public string? Estado { get; set; }
}
