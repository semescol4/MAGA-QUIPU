﻿using sgmo_conector_relojes.AmericaPeru.DTO;

namespace sgmo_conector_relojes.AmericaPeru.Services.Interfaces;

public interface IAmericaPeruWebApiConnector
{
    Task<MarcajeItem[]> GetMarcajesForDate(DateTime dateTime);
}