﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using sgmo_conector_relojes.AmericaPeru.DTO;
using sgmo_conector_relojes.AmericaPeru.DTO.Extensions;
using sgmo_conector_relojes.AmericaPeru.Services.Interfaces;
using System.Text.Json;

namespace sgmo_conector_relojes.AmericaPeru.Services;

public class AmericaPeruWebApiConnector(ILogger<AmericaPeruWebApiConnector> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration) : IAmericaPeruWebApiConnector
{
    private readonly ILogger<AmericaPeruWebApiConnector> _logger = logger;
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _urlTemplate = configuration.GetValue<string>("AmericaPeruApiUrl") ?? throw new Exception("Debe agregar la setting: AmericaPeruApiUrl.");
    private readonly int _timeout = configuration.GetValue<int>("AmericaPeruApiUrl:TimeoutSeconds");

    /// <summary>
    /// Devuelve marcajes para el día. No devuelve fechas superiores, si las hubiera.
    /// </summary>
    /// <param name="dateTime"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public async Task<MarcajeItem[]> GetMarcajesForDate(DateTime dateTime)
    {
        var url = string.Format(_urlTemplate, dateTime.ToString("dd-MM-yyyy"));
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);

        var response = await client.GetAsync(url);
        response.EnsureSuccessStatusCode();

        if (_logger.IsEnabled(LogLevel.Information))
        {
            var jsonResultado = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Mensaje obtenido de servicio: {jsonResultado}", jsonResultado);
        }

        var stream = await response.Content.ReadAsStreamAsync();

        var marcajesResponse = await JsonSerializer.DeserializeAsync<MarcajesResponse>(stream);

        return marcajesResponse.Items.Where(x =>
        {
            if (_logger.IsEnabled(LogLevel.Information))
            {
                var itemSerialized = JsonSerializer.Serialize(x);

                _logger.LogInformation("Procesando item: {itemSerialized}", itemSerialized);
            }

            var fecha = x.GetParsedKznMrcRlj();

            var isDateValid = dateTime.Date.AddHours(3) <= fecha && fecha <= dateTime.Date.AddDays(1).AddHours(3);

            if (_logger.IsEnabled(LogLevel.Information))
            {
                _logger.LogInformation("Item procesado, considerado válido: {isDateValid}", isDateValid);
            }

            return isDateValid;
        }).ToArray();
    }
}