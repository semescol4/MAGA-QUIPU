﻿namespace SGMO.Ficha.Proceso.DTO;

public class FichaProcesoRequest
{
    public string UserName { get; set; }
    public DateTime DateTo { get; set; }
}