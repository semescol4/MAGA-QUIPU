﻿using Microsoft.Extensions.Configuration;
using SGMO.Ficha.Proceso.Services.Interfaces;

namespace SGMO.Ficha.Proceso.Services;

public class LastRunTracker(IConfiguration configuration) : ILastRunTracker
{
    private const string FILEDATEFORMAT = "dd-MM-yyyy";
    private readonly string _lastRunTrackFile = configuration.GetValue<string>("LastRunTrackFile");


    private static string GetFormattedForLogDate(DateTime aDateTime)
    {
        return aDateTime.ToString(FILEDATEFORMAT);
    }

    public async Task SaveFechaEjecucion()
    {
        var lastRunDateTime = DateTime.Now;
        var lastRunDateTimeToFile = GetFormattedForLogDate(lastRunDateTime);

        await File.WriteAllTextAsync(_lastRunTrackFile, lastRunDateTimeToFile);
    }
}