﻿using Microsoft.Extensions.Configuration;
using SGMO.Ficha.Proceso.DTO;
using SGMO.Ficha.Proceso.Services.Interfaces;

namespace SGMO.Ficha.Proceso.Services;

internal class SGMORunner(IConfiguration configuration, IHttpClientFactory httpClientFactory) : ISGMORunner
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly string _url = configuration.GetValue<string>("SGMOApiUrl");
    private readonly int _timeout = configuration.GetValue<int>("SGMOApiUrl:TimeoutSeconds");

    public async Task Process(DateTime dateTo)
    {
        var request = new FichaProcesoRequest
        {
            UserName = "SGMO-Interfaz",
            DateTo = dateTo
        };

        var uri = new Uri(_url);
        var client = _httpClientFactory.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(_timeout);

        var response = await client.PostAsJsonAsync(uri, request);

        response.EnsureSuccessStatusCode();
    }
}