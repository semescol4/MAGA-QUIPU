﻿namespace SGMO.Ficha.Proceso.Services.Interfaces;

public interface ISGMOFichadaRunner
{
    Task Process();
}