﻿using SGMO.Ficha.Proceso.Services.Interfaces;

namespace SGMO.Ficha.Proceso.Services;

public class SGMOFichadaRunner(ILastRunTracker lastRunTracker, ISGMORunner sgmoRunner) : ISGMOFichadaRunner
{
    private readonly ILastRunTracker _lastRunTracker = lastRunTracker;
    private readonly ISGMORunner _sgmoRunner = sgmoRunner;

    public async Task Process()
    {
        var fechaHastaEjecucion = DateTime.Now;

        await _sgmoRunner.Process(fechaHastaEjecucion);

        await _lastRunTracker.SaveFechaEjecucion();
    }
}
