﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SGMO.Ficha.Proceso.Services;
using SGMO.Ficha.Proceso.Services.Interfaces;

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .AddCommandLine(args)
    .Build();

var serviceProvider = new ServiceCollection()
    .AddLogging(config =>
        {
            config.AddConfiguration(configuration.GetSection("Logging"));
            config.AddConsole(c =>
            {
                c.TimestampFormat = "[HH:mm:ss.fff] ";
            });
        })
    .AddSingleton<IConfiguration>(configuration)
    .AddSingleton<ILastRunTracker, LastRunTracker>()
    .AddSingleton<ISGMORunner, SGMORunner>()
    .AddSingleton<ISGMOFichadaRunner, SGMOFichadaRunner>()
    .AddHttpClient()
    .BuildServiceProvider();

using (serviceProvider)
{
    var fichadaRunner = serviceProvider.GetRequiredService<ISGMOFichadaRunner>();

    try
    {
        await fichadaRunner.Process();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.ToString());
        Environment.Exit(1);

        throw;
    }
}